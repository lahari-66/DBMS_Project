<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$property_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM properties WHERE property_id = :property_id AND user_id = :user_id AND status = 'available'";
$stmt = $pdo->prepare($sql);
$stmt->execute([':property_id' => $property_id, ':user_id' => $user_id]);
$property = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$property) {
    die("Property not found or not editable.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $property_type = $_POST['property_type'];
        $property_size = $_POST['property_size'];
        $size_unit = $_POST['size_unit'];
        $ownership_status = $_POST['ownership_status'];
        $features = $_POST['features'];
        $description = $_POST['description'];
        $estimated_price_per_unit = $_POST['estimated_price_per_unit'];
        $total_value = $_POST['total_value'];
        $future_value = $_POST['future_value'] ?: null;
        $seller_type = $_POST['seller_type'];
        $negotiation = isset($_POST['negotiation']) ? 1 : 0;
        $brokering = isset($_POST['brokering']) ? 1 : 0;
        $location = $_POST['location'];
        $city = $_POST['city'];
        $usage_type = $_POST['usage_type'];
        $image_url = $_POST['image_url'] ?? $property['image_url']; // Retain existing value if not provided

        $sql = "UPDATE properties SET 
                property_type = :property_type, property_size = :property_size, size_unit = :size_unit, 
                ownership_status = :ownership_status, features = :features, description = :description, 
                estimated_price_per_unit = :estimated_price_per_unit, total_value = :total_value, 
                future_value = :future_value, seller_type = :seller_type, negotiation = :negotiation, 
                brokering = :brokering, location = :location, city = :city, usage_type = :usage_type,
                image_url = :image_url
                WHERE property_id = :property_id AND user_id = :user_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':property_type' => $property_type,
            ':property_size' => $property_size,
            ':size_unit' => $size_unit,
            ':ownership_status' => $ownership_status,
            ':features' => $features,
            ':description' => $description,
            ':estimated_price_per_unit' => $estimated_price_per_unit,
            ':total_value' => $total_value,
            ':future_value' => $future_value,
            ':seller_type' => $seller_type,
            ':negotiation' => $negotiation,
            ':brokering' => $brokering,
            ':location' => $location,
            ':city' => $city,
            ':usage_type' => $usage_type,
            ':image_url' => $image_url,
            ':property_id' => $property_id,
            ':user_id' => $user_id
        ]);
        $success = "Property updated successfully!";
    } catch (PDOException $e) {
        $error = "Error updating property: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>REMA - Edit Property</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3f37c9;
            --primary-dark: #372fb5;
            --secondary: #4361ee;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1 {
            color: var(--primary);
            font-weight: 600;
            font-size: 28px;
            margin-bottom: 20px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 14px;
            background-color: var(--primary);
            color: white;
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--light-gray);
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(63, 55, 201, 0.2);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .alert-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .grid {
            display: grid;
            gap: 20px;
        }
        
        .grid-cols-3 {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        a {
            color: var(--primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        a:hover {
            color: var(--primary-dark);
        }
        
        @media (max-width: 768px) {
            .grid-cols-3 {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Edit Property</h1>
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="grid grid-cols-3">
                    <div class="form-group">
                        <label class="form-label">Property Type:</label>
                        <select name="property_type" class="form-control" required>
                            <option value="plot" <?php if ($property['property_type'] == 'plot') echo 'selected'; ?>>Plot</option>
                            <option value="flat" <?php if ($property['property_type'] == 'flat') echo 'selected'; ?>>Flat</option>
                            <option value="villa" <?php if ($property['property_type'] == 'villa') echo 'selected'; ?>>Villa</option>
                            <option value="farm_land" <?php if ($property['property_type'] == 'farm_land') echo 'selected'; ?>>Farm Land</option>
                            <option value="farm_house" <?php if ($property['property_type'] == 'farm_house') echo 'selected'; ?>>Farm House</option>
                            <option value="barren_land" <?php if ($property['property_type'] == 'barren_land') echo 'selected'; ?>>Barren Land</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size:</label>
                        <input type="number" name="property_size" step="0.01" value="<?php echo $property['property_size']; ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size Unit:</label>
                        <select name="size_unit" class="form-control">
                            <option value="sqm" <?php if ($property['size_unit'] == 'sqm') echo 'selected'; ?>>Square Meters</option>
                            <option value="sqyd" <?php if ($property['size_unit'] == 'sqyd') echo 'selected'; ?>>Square Yards</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Ownership Status:</label>
                        <select name="ownership_status" class="form-control" required>
                            <option value="sole" <?php if ($property['ownership_status'] == 'sole') echo 'selected'; ?>>Sole Ownership</option>
                            <option value="co_owned" <?php if ($property['ownership_status'] == 'co_owned') echo 'selected'; ?>>Co-Owned</option>
                            <option value="mortgaged" <?php if ($property['ownership_status'] == 'mortgaged') echo 'selected'; ?>>Under Mortgage</option>
                            <option value="leased" <?php if ($property['ownership_status'] == 'leased') echo 'selected'; ?>>Leased/Occupied</option>
                            <option value="pending_transfer" <?php if ($property['ownership_status'] == 'pending_transfer') echo 'selected'; ?>>Pending Transfer</option>
                            <option value="disputed" <?php if ($property['ownership_status'] == 'disputed') echo 'selected'; ?>>Disputed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Price per Unit:</label>
                        <input type="number" name="estimated_price_per_unit" step="0.01" value="<?php echo $property['estimated_price_per_unit']; ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Value:</label>
                        <input type="number" name="total_value" step="0.01" value="<?php echo $property['total_value']; ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Future Value (optional):</label>
                        <input type="number" name="future_value" step="0.01" value="<?php echo $property['future_value']; ?>" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Seller Type:</label>
                        <select name="seller_type" class="form-control" required>
                            <option value="owner" <?php if ($property['seller_type'] == 'owner') echo 'selected'; ?>>Owner</option>
                            <option value="third_party" <?php if ($property['seller_type'] == 'third_party') echo 'selected'; ?>>Third Party</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="negotiation" id="negotiation" <?php if ($property['negotiation']) echo 'checked'; ?>>
                            <label for="negotiation" class="form-label">Negotiation</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="brokering" id="brokering" <?php if ($property['brokering']) echo 'checked'; ?>>
                            <label for="brokering" class="form-label">Brokering</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Location:</label>
                        <input type="text" name="location" value="<?php echo $property['location']; ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">City:</label>
                        <input type="text" name="city" value="<?php echo $property['city']; ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Usage Type:</label>
                        <select name="usage_type" class="form-control" required>
                            <option value="sale" <?php if ($property['usage_type'] == 'sale') echo 'selected'; ?>>Sale</option>
                            <option value="rent" <?php if ($property['usage_type'] == 'rent') echo 'selected'; ?>>Rent</option>
                            <option value="lease" <?php if ($property['usage_type'] == 'lease') echo 'selected'; ?>>Lease</option>
                            <option value="development" <?php if ($property['usage_type'] == 'development') echo 'selected'; ?>>Development</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Features:</label>
                        <textarea name="features" class="form-control"><?php echo $property['features']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description:</label>
                        <textarea name="description" class="form-control"><?php echo $property['description']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Property Image URL (optional):</label>
                        <input type="text" name="image_url" value="<?php echo $property['image_url'] ?? ''; ?>" class="form-control" placeholder="Enter image URL">
                    </div>
                </div>
                <button type="submit" class="btn">Update Property</button>
            </form>
            <a href="seller_dashboard.php" style="display: block; margin-top: 20px;"><i class="fas fa-arrow-left"></i> Back to Seller Dashboard</a>
        </div>
    </div>
</body>
</html>