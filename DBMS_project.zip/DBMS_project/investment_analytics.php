<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch market trends (average prices by city and property type)
$sql = "SELECT city, property_type, AVG(avg_price) AS avg_price 
        FROM market_trends 
        GROUP BY city, property_type 
        ORDER BY city, property_type";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$market_trends = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch user's listed properties for sellers (investment potential)
$sql = "SELECT property_id, property_type, city, total_value, future_value 
        FROM properties 
        WHERE user_id = :user_id AND future_value IS NOT NULL";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$user_properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch user's purchased properties for buyers (investment potential)
$sql = "SELECT p.property_id, p.property_type, p.city, p.total_value, p.future_value 
        FROM properties p 
        JOIN transactions t ON p.property_id = t.property_id 
        WHERE t.buyer_id = :user_id AND p.future_value IS NOT NULL";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$purchase_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>REMA - Investment Analytics</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3f37c9;
            --primary-dark: #372fb5;
            --secondary: #4361ee;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .dashboard-header h1 {
            color: var(--primary);
            font-weight: 600;
            font-size: 28px;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 14px;
            background-color: var(--primary);
            color: white;
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .table th {
            background-color: var(--primary);
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--light-gray);
            vertical-align: middle;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .table tr:hover {
            background-color: rgba(63, 55, 201, 0.05);
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background-color: rgba(248, 150, 30, 0.1);
            color: var(--warning);
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--light-gray);
        }
        
        @media (max-width: 768px) {
            .table th, .table td {
                padding: 8px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-header">
            <h1>Investment Analytics</h1>
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>

        <!-- Market Trends Section -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Market Trends</h2>
            </div>
            <?php if (!empty($market_trends)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>City</th>
                                <th>Property Type</th>
                                <th>Average Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($market_trends as $trend): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($trend['city']); ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $trend['property_type'])); ?></td>
                                    <td>$<?php echo number_format($trend['avg_price'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-chart-line"></i>
                    <p>No market trend data available yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Seller's Listed Properties Analytics -->
        <?php if (!empty($user_properties)): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Your Listed Properties - Investment Potential</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Property ID</th>
                                <th>Type</th>
                                <th>City</th>
                                <th>Current Value</th>
                                <th>Future Value</th>
                                <th>Potential Gain</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($user_properties as $property): ?>
                                <?php
                                $potential_gain = $property['future_value'] - $property['total_value'];
                                $gain_class = $potential_gain > 0 ? 'badge-success' : 'badge-warning';
                                ?>
                                <tr>
                                    <td><?php echo $property['property_id']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $property['property_type'])); ?></td>
                                    <td><?php echo htmlspecialchars($property['city']); ?></td>
                                    <td>$<?php echo number_format($property['total_value'], 2); ?></td>
                                    <td>$<?php echo number_format($property['future_value'], 2); ?></td>
                                    <td><span class="status-badge <?php echo $gain_class; ?>">$<?php echo number_format($potential_gain, 2); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- Buyer's Purchased Properties Analytics -->
        <?php if (!empty($purchase_history)): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Your Purchased Properties - Investment Potential</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Property ID</th>
                                <th>Type</th>
                                <th>City</th>
                                <th>Current Value</th>
                                <th>Future Value</th>
                                <th>Potential Gain</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($purchase_history as $property): ?>
                                <?php
                                $potential_gain = $property['future_value'] - $property['total_value'];
                                $gain_class = $potential_gain > 0 ? 'badge-success' : 'badge-warning';
                                ?>
                                <tr>
                                    <td><?php echo $property['property_id']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $property['property_type'])); ?></td>
                                    <td><?php echo htmlspecialchars($property['city']); ?></td>
                                    <td>$<?php echo number_format($property['total_value'], 2); ?></td>
                                    <td>$<?php echo number_format($property['future_value'], 2); ?></td>
                                    <td><span class="status-badge <?php echo $gain_class; ?>">$<?php echo number_format($potential_gain, 2); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <a href="dashboard.php" class="btn" style="display: block; text-align: center; margin-top: 20px;">
            <i class="fas fa-arrow-left"></i> Back to Main Dashboard
        </a>
    </div>
</body>
</html>