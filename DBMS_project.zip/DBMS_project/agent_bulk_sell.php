<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['property_ids'])) {
    header("Location: agent_dashboard.php?action=sell&error=" . urlencode("No properties selected or session expired."));
    exit();
}

$agent_id = $_SESSION['user_id'];
$property_ids = $_POST['property_ids'];

if (!is_array($property_ids) || empty($property_ids)) {
    header("Location: agent_dashboard.php?action=sell&error=" . urlencode("No valid properties selected."));
    exit();
}

try {
    $pdo->beginTransaction();
    $success_count = 0;

    foreach ($property_ids as $property_id) {
        // Sanitize property_id
        $property_id = filter_var($property_id, FILTER_SANITIZE_NUMBER_INT);
        if (!$property_id) {
            continue; // Skip invalid IDs
        }

        // Verify the property belongs to the agent and is available
        $sql = "SELECT * FROM properties WHERE property_id = :property_id AND user_id = :user_id AND status = 'available'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':property_id' => $property_id, ':user_id' => $agent_id]);
        $property = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($property) {
            $sql = "INSERT INTO transactions (property_id, agent_id, transaction_type, status) 
                    VALUES (:property_id, :agent_id, :transaction_type, 'pending')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':property_id' => $property_id,
                ':agent_id' => $agent_id,
                ':transaction_type' => $property['usage_type']
            ]);

            $sql = "UPDATE properties SET status = 'pending' WHERE property_id = :property_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':property_id' => $property_id]);
            $success_count++;
        }
    }

    $pdo->commit();
    $success_message = "Bulk sell request submitted successfully for $success_count properties!";
    header("Location: agent_dashboard.php?action=sell&success=" . urlencode($success_message));
    exit();
} catch (PDOException $e) {
    $pdo->rollBack();
    $error_message = "Error processing bulk sell: " . $e->getMessage();
    header("Location: agent_dashboard.php?action=sell&error=" . urlencode($error_message));
    exit();
}
?>
