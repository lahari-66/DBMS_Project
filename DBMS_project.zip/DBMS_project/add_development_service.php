<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $service_name = $_POST['service_name'];
        $description = $_POST['description'];
        
        // First check if service exists
        $sql = "SELECT * FROM development_services WHERE service_name = :service_name";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':service_name' => $service_name]);
        $service = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$service) {
            // Create new service
            $sql = "INSERT INTO development_services (service_name, description) VALUES (:service_name, :description)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':service_name' => $service_name, ':description' => $description]);
            $service_id = $pdo->lastInsertId();
        } else {
            $service_id = $service['service_id'];
        }
        
        // Link to agent
        $sql = "INSERT INTO agent_services (agent_id, service_id) VALUES (:agent_id, :service_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':agent_id' => $_SESSION['user_id'], ':service_id' => $service_id]);
        
        header("Location: agent_dashboard.php?action=development");
        exit();
    } catch (PDOException $e) {
        die("Error adding service: " . $e->getMessage());
    }
}
?>