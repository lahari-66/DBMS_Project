<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$properties = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $city = filter_input(INPUT_POST, 'city', FILTER_SANITIZE_STRING);
        $property_type = filter_input(INPUT_POST, 'property_type', FILTER_SANITIZE_STRING);
        $usage_type = filter_input(INPUT_POST, 'usage_type', FILTER_SANITIZE_STRING);
        $min_price = filter_input(INPUT_POST, 'min_price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) ?: 0;
        $max_price = filter_input(INPUT_POST, 'max_price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) ?: 999999999;
        $min_size = filter_input(INPUT_POST, 'min_size', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) ?: 0;
        $max_size = filter_input(INPUT_POST, 'max_size', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) ?: 999999999;
        $negotiation = isset($_POST['negotiation']) ? 1 : null;
        $brokering = isset($_POST['brokering']) ? 1 : null;

        if (!$city || !$property_type || !$usage_type) {
            throw new Exception("Required fields are missing.");
        }

        $sql = "SELECT * FROM properties 
                WHERE city = :city 
                AND property_type = :property_type 
                AND usage_type = :usage_type 
                AND total_value BETWEEN :min_price AND :max_price 
                AND property_size BETWEEN :min_size AND :max_size 
                AND status = 'available'";
        if ($negotiation !== null) $sql .= " AND negotiation = :negotiation";
        if ($brokering !== null) $sql .= " AND brokering = :brokering";

        $stmt = $pdo->prepare($sql);
        $params = [
            ':city' => $city,
            ':property_type' => $property_type,
            ':usage_type' => $usage_type,
            ':min_price' => $min_price,
            ':max_price' => $max_price,
            ':min_size' => $min_size,
            ':max_size' => $max_size
        ];
        if ($negotiation !== null) $params[':negotiation'] = $negotiation;
        if ($brokering !== null) $params[':brokering'] = $brokering;
        
        $stmt->execute($params);
        $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $error = "Error searching properties: " . $e->getMessage();
    }
}

// Fetch user's purchase history with development status
$sql = "SELECT p.*, t.transaction_type, t.status AS transaction_status,
        dr.status AS development_status
        FROM transactions t 
        JOIN properties p ON t.property_id = p.property_id 
        LEFT JOIN development_requests dr ON p.property_id = dr.property_id AND dr.buyer_id = :buyer_id
        WHERE t.buyer_id = :buyer_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':buyer_id' => $_SESSION['user_id']]);
$purchase_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>REMA - Buyer Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #f72585;
            --primary-dark: #d61a6f;
            --secondary: #b5179e;
            --success: #4cc9f0;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .dashboard-header h1 {
            color: var(--primary);
            font-weight: 600;
            font-size: 28px;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .nav-header {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
        }
        
        .nav-menu li {
            flex: 1;
        }
        
        .nav-menu a {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px 10px;
            color: var(--gray);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .nav-menu a:hover, .nav-menu a.active {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--primary);
        }
        
        .nav-menu i {
            font-size: 18px;
            margin-bottom: 5px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--light-gray);
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(247, 37, 133, 0.2);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .table th {
            background-color: var(--primary);
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--light-gray);
            vertical-align: middle;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .table tr:hover {
            background-color: rgba(247, 37, 133, 0.05);
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background-color: rgba(248, 150, 30, 0.1);
            color: var(--warning);
        }
        
        .badge-info {
            background-color: rgba(72, 149, 239, 0.1);
            color: var(--info);
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--primary);
            border-left: 4px solid var(--primary);
        }
        
        .grid {
            display: grid;
            gap: 20px;
        }
        
        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .grid-cols-4 {
            grid-template-columns: repeat(4, 1fr);
        }
        
        .action-link {
            color: var(--primary);
            text-decoration: none;
            margin-right: 10px;
            transition: color 0.3s ease;
        }
        
        .action-link:hover {
            color: var(--primary-dark);
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--light-gray);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .price-range {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        @media (max-width: 768px) {
            .grid-cols-2, .grid-cols-4 {
                grid-template-columns: 1fr;
            }
            
            .price-range {
                grid-template-columns: 1fr;
            }
            
            .table th, .table td {
                padding: 8px 10px;
            }
            
            .nav-menu {
                flex-direction: column;
            }
        }
    </style>
    <script>
        // Smooth scrolling for in-page navigation
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.nav-menu a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href').substring(1);
                    const targetElement = document.getElementById(targetId);
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth' });
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="dashboard-header">
            <h1 id="dashboard-title">Buyer Dashboard</h1>
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <div class="nav-header" id="header-nav">
            <ul class="nav-menu">
                <li>
                    <a href="#search-properties">
                        <i class="fas fa-search"></i>
                        <span>Search</span>
                    </a>
                </li>
                <li>
                    <a href="#available-properties">
                        <i class="fas fa-home"></i>
                        <span>Properties</span>
                    </a>
                </li>
                <li>
                    <a href="#purchase-history">
                        <i class="fas fa-history"></i>
                        <span>History</span>
                    </a>
                </li>
                <li>
                    <a href="investment_analytics.php">
                        <i class="fas fa-chart-line"></i>
                        <span>Analytics</span>
                    </a>
                </li>
                <li>
                    <a href="dashboard.php">
                        <i class="fas fa-arrow-left"></i>
                        <span>Main Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="card" id="search-properties">
            <div class="card-header">
                <h2 class="card-title">Search Properties</h2>
                <a href="investment_analytics.php" class="btn btn-outline"><i class="fas fa-chart-line"></i> View Analytics</a>
            </div>
            <?php if (isset($error)) echo "<div class='alert alert-danger'>" . htmlspecialchars($error) . "</div>"; ?>
            <form method="POST">
                <div class="grid grid-cols-4">
                    <div class="form-group">
                        <label class="form-label">City:</label>
                        <input type="text" name="city" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Property Type:</label>
                        <select name="property_type" class="form-control" required>
                            <option value="plot">Plot</option>
                            <option value="flat">Flat</option>
                            <option value="villa">Villa</option>
                            <option value="farm_land">Farm Land</option>
                            <option value="farm_house">Farm House</option>
                            <option value="barren_land">Barren Land</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Usage Type:</label>
                        <select name="usage_type" class="form-control" required>
                            <option value="sale">Sale</option>
                            <option value="rent">Rent</option>
                            <option value="lease">Lease</option>
                            <option value="development">Development</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Price Range:</label>
                        <div class="price-range">
                            <input type="number" name="min_price" step="0.01" class="form-control" placeholder="Min Price">
                            <input type="number" name="max_price" step="0.01" class="form-control" placeholder="Max Price">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size Range (sqm):</label>
                        <div class="price-range">
                            <input type="number" name="min_size" step="0.01" class="form-control" placeholder="Min Size">
                            <input type="number" name="max_size" step="0.01" class="form-control" placeholder="Max Size">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="negotiation" id="negotiation">
                            <label for="negotiation" class="form-label">Negotiation Available</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="brokering" id="brokering">
                            <label for="brokering" class="form-label">Brokering Available</label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Search Properties</button>
            </form>
        </div>

        <div class="card" id="available-properties">
            <div class="card-header">
                <h2 class="card-title">Available Properties</h2>
            </div>
            <?php if (!empty($properties)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Size</th>
                                <th>Location</th>
                                <th>City</th>
                                <th>Total Value</th>
                                <th>Negotiation</th>
                                <th>Brokering</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($properties as $property): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($property['property_id']); ?></td>
                                    <td><?php echo htmlspecialchars($property['property_type']); ?></td>
                                    <td><?php echo htmlspecialchars($property['property_size'] . ' ' . $property['size_unit']); ?></td>
                                    <td><?php echo htmlspecialchars($property['location']); ?></td>
                                    <td><?php echo htmlspecialchars($property['city']); ?></td>
                                    <td>$<?php echo number_format(htmlspecialchars($property['total_value']), 2); ?></td>
                                    <td><?php echo $property['negotiation'] ? '<span class="status-badge badge-success">Yes</span>' : '<span class="status-badge badge-warning">No</span>'; ?></td>
                                    <td><?php echo $property['brokering'] ? '<span class="status-badge badge-success">Yes</span>' : '<span class="status-badge badge-warning">No</span>'; ?></td>
                                    <td>
                                        <a href="buy_property.php?id=<?php echo urlencode($property['property_id']); ?>" class="btn btn-primary btn-sm">Buy</a>
                                        <a href="view_image.php?id=<?php echo urlencode($property['property_id']); ?>" class="action-link"><i class="fas fa-image"></i> Image</a>
                                        <a href="chat.php?property_id=<?php echo urlencode($property['property_id']); ?>&receiver_id=<?php echo urlencode($property['user_id']); ?>" class="action-link"><i class="fas fa-comments"></i> Chat</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <p>No properties found matching your criteria.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="card" id="purchase-history">
            <div class="card-header">
                <h2 class="card-title">Your Purchase History</h2>
            </div>
            <?php if (!empty($purchase_history)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>City</th>
                                <th>Total Value</th>
                                <th>Transaction Type</th>
                                <th>Status</th>
                                <th>Development</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($purchase_history as $purchase): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($purchase['property_id']); ?></td>
                                    <td><?php echo htmlspecialchars($purchase['property_type']); ?></td>
                                    <td><?php echo htmlspecialchars($purchase['city']); ?></td>
                                    <td>$<?php echo number_format(htmlspecialchars($purchase['total_value']), 2); ?></td>
                                    <td><?php echo htmlspecialchars($purchase['transaction_type']); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $purchase['transaction_status'] == 'confirmed' ? 'badge-success' : 'badge-warning'; ?>">
                                            <?php echo htmlspecialchars($purchase['transaction_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($purchase['development_status'] === 'confirmed'): ?>
                                            <a href="view_development.php?property_id=<?php echo urlencode($purchase['property_id']); ?>" class="status-badge badge-success">
                                                View Development
                                            </a>
                                        <?php elseif ($purchase['development_status'] === 'pending'): ?>
                                            <span class="status-badge badge-warning">Pending</span>
                                        <?php elseif ($purchase['transaction_status'] === 'confirmed' && !$purchase['development_status']): ?>
                                            <a href="buyer_development.php?property_id=<?php echo urlencode($purchase['property_id']); ?>" class="status-badge badge-info">
                                                Develop
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>You have not made any purchases yet.</p>
                    <a href="buyer_development.php" class="btn btn-outline" style="margin-top: 15px;">
                        <i class="fas fa-hammer"></i> Manage Development Requests
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <a href="dashboard.php" class="btn btn-primary" style="display: block; text-align: center; margin-top: 20px;">
            <i class="fas fa-arrow-left"></i> Back to Main Dashboard
        </a>
    </div>
</body>
</html>