<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['service_id'])) {
    header("Location: index.php");
    exit();
}

$service_id = $_GET['service_id'];

try {
    $sql = "DELETE FROM agent_services WHERE agent_id = :agent_id AND service_id = :service_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':agent_id' => $_SESSION['user_id'], ':service_id' => $service_id]);
    
    header("Location: agent_dashboard.php?action=development");
    exit();
} catch (PDOException $e) {
    die("Error removing service: " . $e->getMessage());
}
?>